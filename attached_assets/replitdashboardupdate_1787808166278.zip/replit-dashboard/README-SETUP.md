# Next Touch — Replit Dashboard Setup

This is the **display half** of a one-way push: Claude's hourly "Next Touch sync"
scheduled task sends the latest contact data here after every run; this app stores
it and shows it. Nothing on this side ever calls back into Claude — data only
flows Claude → Replit.

## 1. Create the Repl

In Replit, create a new **Node.js** Repl and bring in these files (either drag
the whole folder in, or create matching files and paste the contents):

```
server.js
package.json
public/index.html
public/style.css
public/app.js
```

Then in the Replit Shell:

```
npm install
```

## 2. Set your Secrets

Open the **Secrets** panel (the padlock icon in the left sidebar) and add:

| Key | Value |
|---|---|
| `SYNC_SECRET` | `LT-wx29c41vXnGpCj_L7R3Fuvtr7ym9dpqQsnwVeuks` |
| `DASHBOARD_PASSWORD` | *(optional but recommended — pick your own password)* |

**`SYNC_SECRET` is the password Claude's scheduled task authenticates with when
it pushes data.** It was generated for you — you don't need to make up your own,
just paste it in exactly as shown. Treat it like any other credential: don't
paste it into a public chat, doc, or commit.

**`DASHBOARD_PASSWORD`** is separate — it puts a plain browser login prompt in
front of the dashboard page itself. Worth setting because this data includes
prospect names, emails, and business details. If you leave it unset, anyone with
your Repl's URL can view the dashboard (the `/api/sync` push endpoint is always
protected by `SYNC_SECRET` regardless).

## 3. Run it

Click **Run**. Replit will show a webview with a public URL along the lines of
`https://<your-repl-name>.<your-username>.replit.app` (Replit's exact URL format
has changed over time — use whatever it shows you). That URL is what the
dashboard will be reachable at once deployed.

If you want this always reachable (not just while you have the Repl open),
use Replit's **Deploy** option to get a persistent URL — a Repl that's only
running in the editor will go to sleep and miss scheduled pushes.

## 4. Send the URL back to Claude

Give Claude the deployed URL (e.g. `https://next-touch-dashboard.adamrusso.replit.app`).
Claude will add one step to the end of the existing hourly "Next Touch sync"
scheduled task: after it finishes updating the live Next Touch and Pipeline Pulse
Artifacts, it extracts the current contact data and does an authenticated POST to
`<your-url>/api/sync` with the `SYNC_SECRET` above as a bearer token. From then on,
every hourly sync also lands here automatically.

Claude will do one manual test push first to confirm the endpoint actually works
end-to-end before relying on the unattended hourly version — the same caution
already applied to every other automated piece of this system.

## What the push payload looks like

Updated to include the Contact Brief modal, Call Coach, and This Week data (added
after the initial setup — if you're re-syncing an existing Repl, this is the part
that changed):

```json
{
  "source": "next-touch-sync",
  "syncedAt": "2026-08-27T14:52:00Z",
  "nextTouch": {
    "contacts": [
      {
        "slug": "todd-neider",
        "name": "Todd Neider",
        "business": "Active Bodywork",
        "email": "todd@activebodywork.com",
        "priority": "High",
        "tier": "high",
        "signal": "Need payment updated (agreement signed)",
        "lastContact": "Today, 11:30 AM · reactivation call, agreement signed",
        "upcoming": "None scheduled",
        "notes": "...",
        "action": "...",
        "briefUrl": null,
        "readingTapeUrl": null,
        "coach": { "situation": "...", "lines": [["Label", "Verbiage..."]] },
        "coachSkipNote": null
      }
    ]
  },
  "thisWeek": {
    "weekLabel": "Aug 24-30, 2026",
    "checkedAtLabel": "Aug 27, 8:52 AM MT",
    "days": [
      {
        "date": "2026-08-27",
        "label": "Thursday",
        "isToday": true,
        "meetings": [
          {
            "time": "11:00",
            "name": "...",
            "business": "...",
            "declined": false,
            "review": "Pre-call review text (only for unmatched meetings)",
            "match": {
              "type": "next-touch",
              "nextTouchSlug": "todd-neider",
              "priority": "High",
              "summary": "One-line status blurb"
            }
          }
        ]
      }
    ]
  },
  "pipelinePulse": null
}
```

**`slug` is required on every contact now** — it's what the Contact Brief modal
and This Week's "On Next Touch" links use to look a contact up. Without it, name
clicks and Coach buttons won't be able to find the right contact.

`match.type` on a This Week meeting is one of `"next-touch"` (carries
`nextTouchSlug` + `priority` + a one-line `summary`), `"salesforce"` (carries a
`salesforce: {stage, account, link}` object — `link` can be `null` if not yet
captured), or `"none"` (carries a `review` with a pre-call summary built only from
real calendar details, per the "never guess-assign a meeting" rule this whole
system follows).

`thisWeek` is optional — if it's omitted or empty, the dashboard shows a plain
"not received yet" note in that section instead of breaking.

Sent as:

```
POST /api/sync
Authorization: Bearer <SYNC_SECRET>
Content-Type: application/json
```

## Endpoints this app exposes

- `GET /` — the dashboard page (behind `DASHBOARD_PASSWORD` if set)
- `GET /api/data` — the latest stored snapshot as JSON (same auth as above; this is what `app.js` polls every 60s)
- `POST /api/sync` — where Claude pushes new data (always requires `SYNC_SECRET`, regardless of `DASHBOARD_PASSWORD`)
- `GET /healthz` — unauthenticated, just confirms the server is up

## If you ever want to rotate the secret

Change `SYNC_SECRET` in Replit's Secrets panel to a new value, then tell Claude
the new value so it updates the scheduled task's push step to match. Until both
sides agree, pushes will fail with 401 — that's expected and safe, not data loss
(the dashboard just keeps showing the last successful sync until the secret is
back in sync on both ends).
